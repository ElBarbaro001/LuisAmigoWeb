const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());
const universidades = require('./controlador/universidades.controlador');
const inscripciones = require('./controlador/inscripciones.controlador');
const ponentes = require('./controlador/ponentes.controlador');
const cuestionario = require('./controlador/cuestionario.controlador');
app.use('/api/universidades', universidades);
app.use('/api/inscripcion', inscripciones);
app.use('/api/ponentes', ponentes);
app.use('/api/cuestionario', cuestionario);
app.listen(3000, () => {
  console.log('Servidor corriendo en puerto 3000');
});