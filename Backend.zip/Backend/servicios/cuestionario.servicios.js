const db = require('../db');
// Registrar inscripción
module.exports.registrarCuestionario = async (obj) => {
  const sql = `
    insert into tblcuestionario  values (null,?,?);
  `;
  const [result] = await db.execute(sql, [
    obj.pregunta,
    obj.calificaion
  ]);
  return result.insertId;
};
// Listar inscripciones
module.exports.cuestionario = async () => {
  const [filas] = await db.query(`
    select * from tblcuestionario
  `);
  return filas;
};