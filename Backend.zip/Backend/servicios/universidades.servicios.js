const db = require('../db');
module.exports.registrarUniversidad = async (obj) => {
  const sql = "insert into tbluniversidades (codigo,universidad,cupos) values (null,?,?);";
  const [result] = await db.execute(sql, [obj.universidad,obj.cupos]);
  return result.insertId;
};
module.exports.universidadesRegistradas = async () => {
  const [rows] = await db.query("select * from tbluniversidades order by universidad asc;");
  return rows;
};