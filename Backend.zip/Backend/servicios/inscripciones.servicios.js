const db = require('../db');
// Registrar inscripción
module.exports.registrarInscripcion = async (obj) => {
  const sql = `
    insert into tblinscripcion values (null,?,?,?,?,?,?,?,?,current_timestamp)
  `;
  const [result] = await db.execute(sql, [
    obj.tipodocumento,
    obj.documento,
    obj.primernombre,
    obj.segundonombre,
    obj.primerapellido,
    obj.segundoapellido,
    obj.codigouniversidad,
    obj.sexo
  ]);
  return result.insertId;
};
// Listar inscripciones
module.exports.inscripcionesRegistradas = async () => {
  const [filas] = await db.query(`
    select i.*, u.universidad
    from tblinscripcion i
    join tbluniversidades u on i.codigouniversidad = u.codigo
  `);
  return filas;
};
module.exports.cupos = async(req, res)=>{
  const codigouniversidad = req.params.codigouniversidad;
  const [cupos] = sql(
  `SELECT u.cupos - COUNT(i.codigo) AS cupos_disponibles
    from tbluniversidades u
    LEFT JOIN tblinscripcion i ON u.codigo  = i.codigouniversidad
    WHERE u.codigo = ?
    GROUP BY u.codigo
  `
  );
  const [result] = await db.execute(sql, [codigouniversidad]);
  return result;
}