const db = require('../db');
// Registrar ponentes
module.exports.registrarPonentes = async (obj) => {
  const sql = `
    insert into tblponentes (codigo,nombres,apellidos,profesion,tema)values (null,?,?,?,?)
  `;
  const [result] = await db.execute(sql, [
    obj.nombres,
    obj.apellidos,
    obj.profesion,
    obj.tema
  ]);
  return result.insertId;
};
// Listar ponentes
module.exports.ponentesRegistrados = async () => {
  const [filas] = await db.query(`
    select *
    from tblponentes;
  `);
  return filas;
};