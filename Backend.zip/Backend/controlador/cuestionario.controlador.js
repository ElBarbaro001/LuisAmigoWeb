const express = require('express');
const router = express.Router();
const service = require('../servicios/cuestionario.servicios');
router.post('/', async (req, res) => {
  try {
    const {
      pregunta,
      calificacion
    } = req.body;
    if (!pregunta || !calificacion ) {
      return res.status(400).json({ error: 'Faltan campos obligatorios.' });
    }
    const id = await service.registrarCuestionario({
      pregunta,
      calificacion
    });
    res.status(201).json({ message: 'Pregunta registrada exitosamente.', id });
  } catch (error) {
    console.error('Error al registrar pregunta:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});
router.get('/', async (req, res) => {
  try {
    const preguntas = await service.cuestionario();
    res.json(preguntas);
  } catch (error) {
    console.error('Error al obtener preguntas:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});
module.exports = router;