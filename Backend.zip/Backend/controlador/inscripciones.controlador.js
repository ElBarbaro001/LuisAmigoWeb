const express = require('express');
const router = express.Router();
const service = require('../servicios/inscripciones.servicios');
router.post('/', async (req, res) => {
  try {
    const {
      tipodocumento,
      documento,
      primernombre,
      segundonombre,
      primerapellido,
      segundoapellido,
      codigouniversidad,
      sexo
    } = req.body;
    if (!tipodocumento || !documento || !primernombre || !primerapellido || !codigouniversidad || !sexo) {
      return res.status(400).json({ error: 'Faltan campos obligatorios.' });
    }
    const id = await service.registrarInscripcion({
      tipodocumento,
      documento,
      primernombre,
      segundonombre,
      primerapellido,
      segundoapellido,
      codigouniversidad,
      sexo
    });
    res.status(201).json({ message: 'Inscripción registrada exitosamente.', id });
  } catch (error) {
    console.error('Error al registrar inscripción:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});
router.get('/', async (req, res) => {
  try {
    const inscripciones = await service.inscripcionesRegistradas();
    res.json(inscripciones);
  } catch (error) {
    console.error('Error al obtener inscripciones:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});
router.get('/:codigouniversidad', async (req, res) => {
  try {
    const cupos = await service.cupos();
    res.json(cupos);
  } catch (error) {
    console.error('Error al obtener cupos:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});

// router.get('/:codigo/cupos-disponibles', async (req, res) => {
//   const codigouniversidad = req.params.codigo;
//   const [rows] = await service.query(`
//     SELECT u.cupos - COUNT(i.codigo) AS cupos_disponibles
//     from tbluniversidades u
//     LEFT JOIN tblinscripcion i ON u.codigo  = i.codigouniversidad
//     WHERE u.codigo = ?
//     GROUP BY u.codigo
//   `, [codigouniversidad]);

//   if (rows.length === 0) {
//     return res.status(404).json({ error: 'Universidad no encontrada' });
//   }
//   res.json({ cupos_disponibles: rows[0].cupos_disponibles });
// });
module.exports = router;