const express = require('express');
const router = express.Router();
const service = require('../servicios/ponentes.servicios');
router.post('/', async (req, res) => {
  try {
    const {
      nombres,
      apellidos,
      profesion,
      tema
    } = req.body;
    if (!nombres || !apellidos || !profesion || !tema ) {
      return res.status(400).json({ error: 'Faltan campos obligatorios.' });
    }
    const id = await service.registrarPonentes({
      nombres,
      apellidos,
      profesion,
      tema
    });
    res.status(201).json({ message: 'Ponente registrado exitosamente.', id });
  } catch (error) {
    console.error('Error al registrar ponente:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});
router.get('/', async (req, res) => {
  try {
    const ponentes = await service.ponentesRegistrados();
    res.json(ponentes);
  } catch (error) {
    console.error('Error al obtener ponentes:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});
module.exports = router;