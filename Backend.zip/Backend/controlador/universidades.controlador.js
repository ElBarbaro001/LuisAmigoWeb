const express = require('express');
const router = express.Router();
const service = require('../servicios/universidades.servicios');
router.post('/', async (req, res) => {
  await service.registrarUniversidad(req.body);
  res.status(201).send('Registro Exitoso!');
});
router.get('/', async (req, res) => {
  const registradas = await service.universidadesRegistradas();
  res.send(registradas);
});
module.exports = router;